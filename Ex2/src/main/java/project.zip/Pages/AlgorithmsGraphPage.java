package Pages;

import main.Algorithm;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class AlgorithmsGraphPage extends Page{

    JButton isConnected = new JButton("isConnected ");
    JButton shortestPathDist = new JButton("shortestPathDist ");
    JButton shortestPath = new JButton("shortestPath ");
    JButton center = new JButton("center ");
    JButton tsp = new JButton("tsp ");
    JButton backFromAlgorithms = new JButton("↩");


    public AlgorithmsGraphPage() {
        super();

        panel.add(isConnected);
        isConnected.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(algorithm.isConnected())
                    JOptionPane.showMessageDialog(panel, "This is a connected graph! (TRUE)");
                else
                    JOptionPane.showMessageDialog(panel, "This is not a connected graph! (FALSE)");
            }
        });

        panel.add(shortestPathDist);
        shortestPathDist.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

            }
        });

        panel.add(shortestPath);
        shortestPath.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

            }
        });

        panel.add(center);
        center.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

            }
        });

        panel.add(tsp);
        tsp.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

            }
        });

        panel.add(backFromAlgorithms);
        backFromAlgorithms.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                cl.show(cards, MAINPANEL);
            }
        });
        cards.add(panel, ALGORITHMSPANEL);
    }
}
